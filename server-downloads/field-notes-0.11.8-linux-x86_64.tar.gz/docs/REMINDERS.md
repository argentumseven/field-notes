# Reminders and sound

## Repeating nudges without dates — 0.11.8

Open **Reminders & sound** on a task, note or non-grocery list item and turn on
**Repeat every interval**. Choose an amount and Minutes, Hours, Days, Weeks,
Months or Years. A due date, planned day or event start is not required. The
first nudge is one interval after saving, including a save made offline. The
same cadence survives sync, retries and restarts. Changing its amount, unit or
timezone starts a new cadence when saved; changing sound or importance keeps
the existing start time.

Minutes through weeks count elapsed time. Months and years keep the original
calendar day and local clock where possible: January 31 repeats on February 28
and then March 31. Only the latest missed nudge is caught up after a gap. Long
intervals are scheduled even beyond the calendar's eight-day reminder horizon.
Completing a task stops its nudges. Turn off the interval and save to stop it
without completing the task. Notes with repeating reminders stay in Later &
reminders; removing them from that view pauses their reminders.

Undated items explain this choice and disable adding reminders relative to a
missing date. Existing date-relative reminders remain paused until a date is
added. A repeat interval and a repeating time window are alternative modes;
date-relative alerts can coexist with either. All modes retain their existing
recipient, sound, notification privacy and per-phone reminder preferences.

Update the paired server and Android app to 0.11.8 for interval controls. Older
apps continue to read compatible reminder fields and edit ordinary task details.
The server refuses an older reminder editor's attempt to erase an interval.
Content export/import and content-checkpoint restoration keep the complete rule,
including its original start time. No pairing reset is needed.

## Settings and scheduling repair — 0.11.8

The Android Settings menu opens separate pages for Reminders, Sound & alarms,
Notifications, Widgets, Appearance, Privacy, Connection & background, App updates,
Data & recovery, and Account & installation. Each page has a Settings back button
and its own scroll area.

A **Needs attention** scheduling warning concerns Android's ability to schedule
or display saved reminders; it does not mean the task itself is lost. Tap
**Review reminder setup** to open **Settings → Reminders**. Follow the numbered
notification/precise-reminder permission checks, tap **Retry reminder scheduling**,
then **Test notification**. Storage failures explain that storage must be freed.
Recovered scheduling failures clear automatically after a successful check;
unrelated sound and volume warnings stay available for review. A malformed item
schedule names the affected item and its Reminders & sound control.

Android can delay inexact alarms, background work and stopped-profile delivery.
These settings do not override Android or GrapheneOS restrictions. Cached local
reminders do not wait for a server connection.

## Notification or alarm

**Notification** plays one short cue (under a second) at notification volume.
Choose Chime, Bell, Pulse or Marimba. It respects Silent, Vibrate and DND and
does not repeat or take over the alarm stream. A requested temporary notification
volume change needs its own phone permission and restores after that one sound.

**Alarm** uses a separate set of sustained phrases: Beacon, Orbit, Sunrise or
Siren. It uses Android's alarm stream, rings for the selected duration (five
seconds by default), and offers **Stop alarm**. Stopping or reaching the time
limit restores any app-owned temporary volume change.

An alarm always appears on screen: it posts to its own **Alarms** notification
channel at high importance, with **Stop alarm** and **Open item**, whatever
importance the reminder has. The channel itself is silent; Field Notes plays the
sound, so there is one audible path. Opening the alarm (tapping it or **Open
item**) also silences it, and swiping it away stops it. When the sound ends the
same notification stays as an ordinary card without the Stop control. The older
per-importance alarm channels were replaced by this one, so Android settings show
a single Alarms entry. Android's DND and channel settings still decide whether it
pops up; a phone that is locked with its screen off shows it when the screen next
wakes. A lock-screen alarm screen that wakes the display is not part of this.

The sound eases in over a fraction of a second (Sunrise over about a second) and
fades out over under half a second at the chosen time, so it neither starts with
a blast nor ends mid-phrase with a cut. The phone's alarm volume is raised only
once the sound is ready and while the player is still silent, and it is restored
after the fade. Alarm clips are whole phrases that repeat without a seam. Vibration
pulses for as long as an alarm sounds and is cancelled with it. Later manual volume choices
take priority. DND remains controlled by Android. Saved older sound choices and
durations remain supported; a mode change chooses an appropriate sound for the
new mode rather than carrying alarm audio into a notification.

The title identifies the actual item. The collapsed summary includes its person,
schedule, type, location and a short notes preview; expand for full details and
activity. **Open item** goes to that item. Alarm playback controls show the same
item details. Notification and lock-screen detail preferences remain independent.

Turning on the appropriate phone volume permission clears its old disabled-volume
warning, including warnings retained by earlier APKs. **Dismiss alert** in the
app, **Dismiss** on the issue notification, or swiping that issue away clears the
current saved warning. It does not disable reminders, hide a newer failure or
suppress future warnings. A restoration failure is never automatically cleared
merely because volume control is enabled.

Open an event, task or a non-grocery list item and expand **Reminders**. Add up to eight alerts
relative to its start. A task date uses 9 AM locally; an event uses its chosen
start. A repeat window works independently of a deadline, including undated
tasks. Saving an explicit empty reminder set disables that item's reminders.
Older items without a reminder setting retain the previous default policy.

Choose **Custom time…** on the website, or **Add reminder → Custom time…**
on Android. Enter an **Amount before** and choose Minutes, Hours, Days, Weeks,
Months or Years. Android's **Time** button changes an existing reminder; Sound
and Remove remain separate. Several reminders may use different units.

Minutes/hours/days/weeks count elapsed time: one day is 24 hours. Months and
years use calendar dates in the saved timezone. March 31 minus one month clamps
to February 28 (29 in a leap year); February 29 minus one year clamps to February
28. Calendar leads preserve the local clock through daylight-saving changes;
a nonexistent clock time moves forward through the gap, and an ambiguous time
uses its first occurrence. The dialog shows the calendar timezone. Date-only
month/year reminders use 9 AM in that saved zone. Existing minute-based reminders
keep their original timing and receipt identities.

The maximum is ten years / 120 months, with corresponding bounds for elapsed
units. Zero means at the start. Reminders before an event need its start; tasks
need a due/planned day and notes need a follow-up time. An independent daily or
weekly reminder window can still be used without a due date. A start-only event
needs no end time.

Use the current app on every phone that should receive month/year or other
extended timing. Compatible older phones still receive their understood alerts
and can amend ordinary content. They do not receive a fake at-start substitute,
and cannot overwrite the newer reminder rules through an older editor. Newer
queued timing on an older server stays retained with a visible explanation.
See [Updates](UPDATES.md).

Choose **Who should receive these reminders?**: Only me, Everyone, an assigned
task's person, or selected household people. New tasks, events and reminder
notes start with Everyone. Existing personal selections stay unchanged. This controls
alerts, not shared calendar visibility. A recipient's own enrolled instances
can each alert; the app does not elect one of that person's phones. Existing
events keep their previous household policy until changed.
Selecting people does not itself create an alert; add a reminder or time window.
The shared web selector keeps **Choose several people** open while you check or
uncheck people, including when only one is currently selected. An empty selected
audience cannot be saved. Grocery items have no reminder editor; list-level
new-item notices remain independently configurable. Existing recipient choices
are preserved instead of silently broadening who receives alerts.
Saving submits a durable change even when the editor closes immediately. If the
phone is offline, it remains queued and visible until connectivity returns;
closing the editor does not abandon that delivery.

Each alert has Quiet, Normal or Urgent importance, vibration and 25/50/75/100%
relative sound levels. Eight original tones are available: Chime, Bell, Pulse,
Beacon, Marimba, Orbit, Sunrise and Siren. Preview uses the current volume and
does not raise it. Regular notifications use the notification stream/channel.

Enable **Alarm** in Delivery mode for 5, 10, 15, 30 or 60 seconds of local playback.
Enable **Temporarily raise alarm volume** and choose the level. On each phone,
also enable **Allow temporary alarm-volume control** in Settings, then try
**Test a loud alarm (5 s)**. This explicitly permits raising a zero/muted alarm
stream; the notification stream and DND policy are unchanged. A visible Stop
action ends playback. The previous alarm volume/mute state is restored afterward,
unless you changed it manually. The recovery record is encrypted and survives
process restart; Android cannot execute recovery while force-stopped. Reopening
the app restores an orphaned change. Use **Stop alarm and restore volume** before
directly force-stopping or uninstalling during playback. In-app removal does
that automatically. Android's DND/audio restrictions remain authoritative.
If Android refuses the original volume or mute state, the app retains recovery
and displays an error directing you to Android sound settings. It does not report
successful restoration. A later manual change takes priority over recovery.
Concurrent alarms play sequentially within a bounded queue; their detailed
notification cards remain available even if audio cannot start.

The website configures these same rules; alarm playback happens on Android.
Update the paired server and all phones to use the new controls. Version 0.4
clients retain basic supported reminders during rollout, with personal alerts
suppressed for nonrecipients; they do not implement longer alarm playback.
Earlier clients should be updated before relying on recipient filtering.
An old editor that could erase advanced rules is rejected with an explanation.

For situational reminders, enable **Repeat during a time window**. Choose its
first day, Once or weekdays, optional last day, From/Until times and an interval
in minutes or hours. The From time is included and Until is excluded. Until
before From continues into the next day; equal times mean a full day. A Monday
overnight window belongs to Monday even after midnight. The saved IANA zone
keeps the routine in the chosen home time when travelling. Nonexistent spring
clock-change occurrences are skipped; repeated autumn times fire once.

These windows repeat notifications, not task copies. Completing a task stops
its reminders; reopening allows future ones. There is no completion-based
recurring task generator, snooze history or
per-occurrence calendar-series editing yet. A future scope must preserve those
differences rather than silently create duplicate tasks.

Android schedules from the encrypted local cache, including offline edits.
AlarmManager keeps a rolling bounded schedule and refills it after delivery,
without a server round trip. Delivered progress and occurrence receipts prevent
retries from sounding again. For repeats, at most the latest missed tick within
ten minutes is caught up; an outage never plays a burst of every missed tick.
Multiple simultaneous rules with the same profile are combined; different sound
profiles remain separate notifications. Very frequent reminders can be delayed
or coalesced by Android, especially under Doze. Exact-alarm permission improves
timing but does not override operating-system limits.

**Detailed reminder notifications** shows the title, local schedule, intended
people, notes, list/project and creator/activity times. New installs show these
in the unlocked shade. Existing off choices are retained, with a one-tap option
to reveal details. **Notification details on the lock screen** is a separate,
default-off choice, also subject to Android's settings. Tapping opens the single
task/event. App credential locking is optional and does not govern these choices.
Delivery failures remain in the app's status, notification and widget footer
until corrected/rechecked; blocked notifications cannot display their own warning.

## GrapheneOS full user profiles

Leave the Field Notes profile running, enable its notification forwarding and
background permission, and use the **30-second profile test** before relying on
it. An ended session cannot deliver alarms. The visible private background
connection and WorkManager fallback use no Google services or OS VPN slot.

Forwarded alerts use the receiving user's system **Other users** notification
channel. That channel controls forwarded sound/volume; GrapheneOS does not copy
each original Field Notes tone. Configure sound and importance for Other users
in the profile you switch to. Quiet source alerts remain quiet. Per-rule tone
and relative loudness apply in the profile running Field Notes. This follows
the [GrapheneOS notification forwarding implementation](https://github.com/GrapheneOS/platform_frameworks_base/blob/785c2d1ccbfa73be98018fd7bc415923605682cc/services/core/java/com/android/server/notification/NotificationManagerService.java#L11275).
Physical cross-profile sound, prolonged Doze and battery behavior remain device
checks; emulator notification delivery does not establish those properties.

See [Android delivery and clean removal](ANDROID-DELIVERY.md).

## Explicit days and clock times — 0.11

In an event's **Reminders** section, choose **Day & time**. Use **Day of**,
**1 day before**, **1 week before**, or the amount and Days/Weeks selectors,
then choose a clock time. A new all-day event starts with day-of at 9 AM. Saved
all-day reminders keep their existing 9 AM anchor until explicitly changed.
No old reminder is moved to midnight. Calendar timezone and daylight-saving rules
are retained with the setting; a skipped spring-forward clock time advances by
the gap and an ambiguous fall-back time uses the earlier occurrence.

Choose one delivery mode: **Notification** or **Alarm**. A new alarm defaults to
**5 seconds**. Existing saved durations, including **Play once**, are retained.
Preview plays the chosen bundled sound. **Test on this phone** exercises actual
delivery; **Stop sound and restore volume** stops playback and restores any
app-owned volume lease. There is one audible playback path for each delivery.

Temporary alarm-volume control and notification-volume control are independent:
both the reminder and the receiving phone must opt in to the relevant stream.
The app saves the previous state durably before changing it, fences replacement
playback, and preserves later manual volume changes. Notification mode respects
Silent/Vibrate; neither mode changes DND. Android and full-profile forwarding
policies still apply. Force-stop or direct uninstall prevents Android from
running cleanup; stop playback first or use Field Notes' clean removal flow.

The app credential lock, Android user unlocking and widget visibility are separate.
A hidden schedule can still sync encrypted content. Unlocking retries widget
visibility without waiting for a new server snapshot; Refresh retries its own
backoff immediately. A profile ended by Android cannot run workers or alarms.
