# Install, build and recover

Server: Linux only, Debian/Ubuntu installer. Android: arm64 GrapheneOS/Android
8+. Linux and Windows use the LAN web interface. Native desktop and iOS builds
are deferred. See [VALIDATION.md](VALIDATION.md) for checks and limits.

For the complete pasteable Debian 13 package/bundle procedure, see
[DEBIAN-INSTALL.md](DEBIAN-INSTALL.md).

## Fresh home server

Install rootful Docker Engine and Compose 2.24+ first, following their verified
distribution instructions. Target Debian 13 or Ubuntu 24.04 LTS with Python 3.11+
and kernel WireGuard support. See [CONTAINERS.md](CONTAINERS.md) for prerequisites
and the isolation policy. Build on Linux with local Docker or unpack the matching
Linux server bundle; both offline images are included:

From a complete Field Notes source checkout on Debian/Ubuntu x86_64,
run as root:

```sh
bash scripts/install-server.sh
```

This one-command installer prompts for configuration, prints a reviewable
no-write plan and requires typing `INSTALL` before preparing toolchains
and building the app/gateway Docker images and server bundle. The bundle uses
the exact APK from the matching public GitHub release, verified against its
pinned signing certificate; the server does not create or need an APK signing
key. It then installs and starts the stack. Rootful Docker
Engine/Compose must already work. After confirmation, the guided installer
installs any missing Debian/Ubuntu build tools (Node/npm, compilers, Make,
packaging tools) with apt before building. It does not change shared Docker
daemon settings.

For a no-write planning run:

```sh
bash scripts/install-server.sh --plan
```

For a complete prebuilt release bundle (no source build):

```sh
bash scripts/install-server.sh --apply
```

The listener IP identifies the private server interface to bind. The trusted
LAN CIDR identifies the **source addresses allowed to use the admin website**;
it may be on a different routed network or VLAN. Do not change the allowed
source CIDR to the server's interface subnet unless those are actually the
administrator clients you intend to authorize. Ensure routing/firewall rules
allow those source IPs to reach the server without rewriting their addresses.

The installer prompts for a LAN IPv4 address, trusted LAN CIDR, optional public
DDNS/IP endpoint (blank for LAN-only), optional WireGuard private /24 overlay
(blank for the generic `10.82.0.0/24`), and the two required ports:

```text
Management HTTPS port (LAN only) (1024–65535, required):
WireGuard UDP port (router forwarding) (1024–65535, required):
```

Both port numbers must be entered explicitly. Neither has a default or a value
derived from another application. TCP 8443 is reserved for the inner API and
cannot be chosen for management. Use an overlay that does not overlap the LAN,
Docker networks or any other VPN.

Before any changes, `--apply` prints the complete plan and requires typing
`INSTALL`. An unconfirmed operation exits without changes. To inspect the
configuration without installing:

```sh
bash scripts/install-server.sh --plan
```

The no-write preview prompts for missing information too. In automation, provide
`--lan-ip`, `--lan-prefix`, `--web-port` and `--udp-port`; `--endpoint` and
`--overlay` are optional. Explicit flags skip the corresponding prompts.
A bare endpoint hostname automatically uses the WireGuard port you selected.
An endpoint with an explicit external `:port` causes the plan to show any
different router NAT mapping.

The initial owner username/password are entered during installation; passwords
are not passed in command-line flags. A fresh installer refuses to overwrite an
existing installation or migration state.

There are three separate listeners:

| Listener | Port | Access |
| --- | --- | --- |
| Management HTTPS | Chosen explicitly during install | Trusted home LAN only |
| WireGuard transport | Chosen explicitly during install | The one router-forwarding candidate |
| Client-to-server HTTPS API | TCP 8443, fixed inside the overlay | Enrolled phone tunnels only; never router-forwarded |

The client API is present separately from management. Enrollment supplies its
inner address to the phones; choosing a WireGuard UDP port does not change the
inner API port.

The installer refuses existing directories, accounts, services and WireGuard
configuration. It is for fresh hosts; it is not an in-place migration from the
older proxy-based prototype. Installation failure leaves reviewable files; do
not blindly rerun over an incomplete installation or delete household data.

The installer installs host WireGuard tools, OpenSSL and kmod, checks the kernel
module, then loads the bundled app/gateway images by immutable ID. It leaves the
shared Docker daemon configuration alone. It creates:

- `/opt/field-notes`: server, constrained host helpers and the read-only `downloads/`
  APK/checksum/signer/metadata bundle. The runtime needs no SDK or APK signing key;
  source builds keep verifier tools in the separate builder cache.
- `/var/lib/field-notes`: app-owned encrypted database, event log and private
  desired-peer manifest; `/etc/field-notes/master.key`: server recovery key.
- `/etc/field-notes/tls`: public CA, root-only `private/ca.key` and separate
  `issued/server.crt`/`issued/server.key`; only `issued/` is mounted into the app.
- `/etc/field-notes/network.json`: public bootstrap identity and trusted outer
  endpoints; root-only `gateway/fieldnotes.conf`: private hub key. Fresh installs
  create no host `/etc/wireguard/fieldnotes.conf` or host nftables table.
- `/etc/field-notes/deployment.json`, `compose.json`, `installation.json`: root-owned
  deployment and removal inventory, including selected ports and image IDs.
- `field-notes.service`: root host supervisor; starts the nonroot, read-only app
  and separate NET_ADMIN gateway, with new outbound traffic/DNS denied.
- `field-notes-peers.timer`: constrained root reconciliation every two seconds,
  acknowledging only a successful apply through the gateway. Private host state
  is in `/var/lib/field-notes-peer-helper`, status in `/run/field-notes-peers`.
- `field-notes-certificates.timer`: daily offline leaf-renewal check; renews when
  fewer than 30 days remain. Rust loads a new valid certificate/key within 60s.
- `/opt/field-notes/uninstall-server.sh`: preview by default; normal removal
  preserves recovery data, explicit purge deletes it. [Removal guide](UNINSTALL.md).

There is no Caddy, reverse proxy or load balancer. Rust serves TLS 1.3 directly
at the LAN address and management port you chose; the separate phone API binds
only `10.82.0.1:8443`.
When the host is inside the allowed admin CIDR, the installer checks login,
authenticated snapshot and logout over real TLS. For a routed admin CIDR that
excludes the host, it verifies the owned runtime version and pinned TLS 1.3
inside the gateway namespace, including the expected HTTP 403 for loopback.
Complete browser login verification from an allowed admin client; the installer
does not broaden the source policy for its own probes.
It does not install a shell-execution endpoint in the management website.

Forward **only the WireGuard UDP port you selected** to the Linux server.
Reserve the server's LAN address, then create an external-to-internal UDP forwarding
rule matching the installer's `router_forward` output. No second application's
port or configuration is needed to choose this value.

This is an opportunity for remote phone access, not an automatic router change.
Never forward the chosen management HTTPS port or inner API TCP 8443.
Preserve any existing unrelated forwarding rules. Keep existing
host firewall restrictions and permit the selected UDP and management LAN as
appropriate. Check the [network access matrix](NETWORK.md) on your actual host;
CGNAT or an upstream UDP filter can prevent remote access. A port change alone
is not a security control. Existing installations retain their configured port;
changing an installation's ports requires a reviewed migration of its live
WireGuard tunnel and enrolled endpoints.

## Trust the LAN website

On the Linux host, verify the public CA fingerprint:

```sh
openssl x509 -in /etc/field-notes/tls/ca.crt -outform DER | sha256sum
```

Transfer only `ca.crt` to your administrator computer and install it in the
appropriate OS/browser trust store after comparing that fingerprint. Never
transfer `private/ca.key`, `server.key` or the server recovery key to phones.
Open the exact management URL shown by the installer. Phones receive the public
CA in their trusted-source QR invitation and need no system-wide CA installation.
See [enrollment steps](ENROLLMENT.md) for scan, code approval, provisioning and
revocation. No manual peer JSON editing is needed.

## Management accounts and passwords

Sign in with the owner name/password chosen during installation. **Management →
People → Add person** creates additional named accounts, each with a separate
initial password, confirmation and role. There is no fixed two-user limit.

Every role, including Viewer, has **Change password** in the sidebar. Enter the
current password and confirm a replacement. **Management → People → Reset
password** resets another person's password after recent administrator
reauthentication. Owners may reset any other active account, including another
owner; administrators may reset members/viewers. Administrators cannot reset
other administrators or owners. Changing your own password in the website requires
the current password, including for an owner.

The installer's suggested owner name is `admin`; existing accounts retain their
selected names. Older container installers could accidentally create the owner
as `field-notes`; inspect with `--list-users` and repair with
`--name field-notes --rename-to admin` as described in the recovery guide.
A lost password can be reset locally by host root with
`python3 /opt/field-notes/reset-password.py --name admin`. Older installs can run
the helper from the current source checkout without rebuilding. See
[account/startup recovery](TROUBLESHOOTING.md).

Passwords use random per-password salts and Argon2id. The server never displays
existing passwords or password hashes. Replacements use the same hashing and
12–256 UTF-8 byte limit. Browser forms confirm the replacement before sending it.
No password is written to the install configuration, audit payloads or command
history. Authentication runs over the direct TLS connection.

A successful change/reset atomically invalidates the affected user's **browser**
sessions. Paired phones and pending invitations keep working by default. Select
**Also sign out paired phones and cancel pending enrollments** when that wider
scope is intended. Phones then need to sign in again; saved offline work remains.
Removing a phone's tunnel is a separate **Revoke device** action. Routine password
maintenance does not silently unpair phones or regenerate device keys. Phone
credentials cannot authorize the LAN website, even if copied to a LAN client.

Copy open web drafts before changing your own password because successful sign-out
clears those drafts. The app's data-encryption master key is separate and unchanged.
If a connection drops during submission, try signing in with the replacement
password before retrying. Self-service proof attempts are limited to five per
five minutes, including across server restarts.

## Install the Android APK

Download the [public APK](https://github.com/argentumseven/field-notes/releases/latest/download/field-notes.apk),
or choose **Download APK** on Sign in or in Management on your trusted
administrator PC and copy it to the phone. Standard builds use the same signer
and exact APK from the matching GitHub release. The phone needs no management
access. App enrollment itself needs no system-wide CA. Software downloads need
no household login; content requires authentication. SHA-256 and certificate
links accompany the server download. The installed server serves its bundled
version without Internet access. Paired phones receive updates through
authenticated chunks on the private notes endpoint. See
[ANDROID-DOWNLOADS.md](ANDROID-DOWNLOADS.md) for verification and custom signers.

Explicit local development build output:
`dist/android/field-notes-0.7.0-android-arm64-debug.apk`, `.sha256`, `.signer.txt`.
Copy the APK to the phone, verify its hash/signing-certificate fingerprint, and
open it with your file manager. Temporarily allow installation from that source.
The debug APK is signed with the development key in the external tool cache;
retain that key for in-place development updates. Do not commit signing keys.

Open **Enroll this phone** on trusted home Wi-Fi and follow [ENROLLMENT.md](ENROLLMENT.md).
Camera access is requested only for scanning. QR decoding is entirely local;
ZXing does not require Play services. Paste is available without camera access.
The app does not consume Android's system VPN slot; existing VPN/lockdown policy
still governs its outer UDP sockets. Test home and mobile-data connectivity on
each phone before relying on background catch-up.

After enrollment, allow notifications and review the default-on background mode.
For widgets, use **Settings & widgets** or the launcher's widget picker. Week,
Calendar, Upcoming and Focus are actual home-screen providers. Unlocked details
default on for new installs; existing choices and separate lock-screen controls
are retained. Follow
[Android delivery and GrapheneOS profiles](ANDROID-DELIVERY.md) for battery,
alarm/sound permissions, full-user-profile forwarding, the delayed test, and
clean revocation/uninstall. The app cannot override a stopped profile or DND.

## Build from source

For a server using the published APK, follow the `--server` setup above. For an
explicit custom Android development build and a server bundling that signer:

```sh
bash scripts/setup/cloud.sh --android
source scripts/dev-env.sh
bash scripts/check.sh
bash scripts/android.sh hostTest lintDebug
bash scripts/build/android.sh debug
FIELD_NOTES_ANDROID_APK=dist/android/field-notes-0.7.0-android-arm64-debug.apk \
  bash scripts/build/server.sh
```

Pinned Kotlin 2.1.21/Compose 1.8.2/AGP 8.10.1/Gradle 8.11.1, JDK 21, Android SDK
36, NDK 28.2 and Go/Rust setup live under `scripts/setup`. Dependencies are locked
and verified. Tool/signing caches remain outside the checkout. The Android build
produces the actual arm64 APK, verifies signature, ZIP/ELF 16 KiB alignment and
manifest constraints. Server builds use fresh staging to prevent stale files
from earlier bundles. Per-target scripts do not report success without artifacts.

An operator release requires a stable separately protected signing key:

```sh
# Supply these securely in your shell/secret manager; never commit their values.
export FIELD_NOTES_KEYSTORE=/protected/path/release.jks
export FIELD_NOTES_KEY_ALIAS=field-notes
# Also set FIELD_NOTES_STORE_PASSWORD and FIELD_NOTES_KEY_PASSWORD securely.
bash scripts/build/android.sh release
```

The release script refuses missing signing inputs. Native Windows/Linux clients
and iOS binaries are not produced by these scripts.

## Development and checks

`node scripts/dev-server.mjs` runs explicit loopback-only HTTP development
listeners with synthetic local data; it is not a production deployment.
`--dev` refuses nonloopback bindings. Installed operation always uses TLS.

```sh
bash scripts/build/android-emulator.sh
node scripts/test-native-client.mjs
# On only the disposable field-notes-test AVD:
# Connect its emulated Wi-Fi first if it has no IPv4 route:
adb -s emulator-5554 shell cmd wifi connect-network AndroidWifi open
node scripts/test-android-emulator.mjs
node scripts/capture-web.mjs
node scripts/capture-android.mjs
```

Software-only AOSP emulation can hit Android job-stop ANRs during cold UI
startup. The current dedicated `field-notes-test` run uses
`ro.hw_timeout_multiplier=10` set before restarting its framework, together with
a 540×1200 / 210-dpi viewport. The emulator's `-prop` option ignores this
non-`qemu.*` property; its startup warning must not be treated as success. This
is disposable AVD setup, never a production-app or physical-phone setting.
Wait for the framework and user to unlock before running captures. The fixture
restores the previous viewport, keeps all assertions, and checks actual launcher
binding, repaint, sleep/unlock and date navigation separately from worker sync.

The capture scripts use synthetic data. Web captures run against a real Rust
server with the matching APK from a built server bundle; `FIELD_NOTES_DOWNLOADS`
can select another verified bundle's downloads directory. Android captures use actual Compose/RemoteViews with a test-only
transport fixture; they do not prove live tunnel enrollment or widget launcher
lifecycle. The separate launcher-icon capture shows the actual installed icon.
Production screen-capture protection is not disabled. See [WALKTHROUGH.md](WALKTHROUGH.md).

## Upgrade without re-pairing

Use [UPDATES.md](UPDATES.md) for the in-app **App updates** screen and the
Linux `scripts/upgrade-server.sh --plan/--apply --bundle PATH` flow. Retain the
original Android signing key and server CA/hub/master keys. Do not purge and
reinstall for a routine upgrade.

## Operation, renewal and recovery

```sh
sudo systemctl status field-notes field-notes-peers.timer field-notes-certificates.timer
sudo journalctl -u field-notes -u field-notes-peers --since today
sudo docker --host=unix:///var/run/docker.sock exec field-notes-gateway wg show fieldnotes
sudo docker --host=unix:///var/run/docker.sock exec field-notes-gateway nft list table inet fieldnotes
```

Do not publish peer manifests, QR material, host configs or unredacted support
logs. Root-owned host configuration/keys need host disk protection. Application
AES-GCM does not encrypt every SQLite metadata field, WireGuard config or memory.

Back up the workspace with **Management → Download encrypted backup**, after
reauthentication. Store the recovery master key separately and protect host
WireGuard, CA and network configuration in a separate host backup. Existing
backups are not erased by clearing active data.

For restore, stop the app and peer timer, preserve a coherent host backup, and
restore into a **new** data directory with the same master key. Run the bundled
image offline, with the dedicated UID/GID and only the needed mounts:

```sh
sudo systemctl stop field-notes-peers.timer field-notes
sudo install -d -o fieldnotes -g fieldnotes -m 700 /var/lib/field-notes-recovery
sudo docker --host=unix:///var/run/docker.sock run --rm --network=none \
  --read-only --cap-drop=ALL --security-opt=no-new-privileges:true \
  --user "$(id -u fieldnotes):$(id -g fieldnotes)" \
  --mount type=bind,src=/var/lib/field-notes-recovery,dst=/recovery \
  --mount type=bind,src=/etc/field-notes/master.key,dst=/keys/master.key,readonly \
  --mount type=bind,src=/protected/path/field-notes.backup,dst=/backup,readonly \
  field-notes-app:0.3.3 restore --data /recovery/restored --key-file /keys/master.key --file /backup
```

The output is `/var/lib/field-notes-recovery/restored`, which must not already
exist. The backup file must be readable by that UID/GID. Preserve its private permissions;
never mount an entire home or root directory. The bundled native CLI requires a
compatible builder libc; the image includes its own runtime libraries and is the
portable Debian/Ubuntu route.

Keep the old directory untouched until recovery is verified. Switching the active
data path is a reviewed maintenance operation: update `deployment.json`, regenerate
`compose.json` from `container_deployment.compose`, update the peer-helper desired
path and the installation inventory's data/deployment paths together. Preserve
root ownership/modes. There is no automatic restore/migration wizard. A restore
changes the epoch, invalidates sessions/invitations, and marks peers for removal.
Re-enroll phones; old offline edits are retained as conflicts. Loss of the master
key cannot be repaired by a password reset. Do not replace unreadable phone vaults
containing offline work.

Manual certificate renewal, preserving the CA:

```sh
sudo python3 -B /opt/field-notes/tls.py renew --issued-subdirectory --directory /etc/field-notes/tls \
  --group fieldnotes --name 192.168.1.10 --name notes.home.arpa --name 10.82.0.1
```

Use the names selected during installation. CA/server-WireGuard identity rotation
needs reviewed re-enrollment; automatic cross-CA trust rotation is not implemented.


## Uninstall

```sh
sudo /opt/field-notes/uninstall-server.sh --plan
sudo /opt/field-notes/uninstall-server.sh --apply
# To delete all managed data and keys instead, use --apply --purge and confirm.
```

Normal removal preserves root-only recovery data. Purge explicitly deletes the
recorded data/configuration directories. Neither removes Docker, WireGuard tools,
other applications or shared resources. See [UNINSTALL.md](UNINSTALL.md) for a later purge,
legacy installations, custom paths and external router/phone cleanup.
